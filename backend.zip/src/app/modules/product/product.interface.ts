export type TProduct = {
  name: string;
  price: number;
  stockQuantity: number;
  description: string;
  category: string;
  ratings: number;
  images?: string[]
  isDeleted: boolean;
};
